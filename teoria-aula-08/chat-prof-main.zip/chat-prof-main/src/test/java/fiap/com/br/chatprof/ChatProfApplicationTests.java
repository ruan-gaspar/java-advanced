package fiap.com.br.chatprof;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatProfApplicationTests {

    @Test
    void contextLoads() {
    }

}
