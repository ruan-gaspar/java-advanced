package fiap.com.br.chatprof.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.util.List;

@Service
public class ChatService {

    private final ChatClient chatClient;

    public ChatService(ChatClient.Builder builder) {
        MessageWindowChatMemory chatMemory = MessageWindowChatMemory.builder().maxMessages(10).build();
        var options = OpenAiChatOptions.builder()
                .temperature(0.7)
                .frequencyPenalty(0.5)
                .stop(List.of("Artemis"))
                .build();

        this.chatClient = builder
                .defaultSystem(
                        """
                               Você é professor de ciências do ensino fundamental.
                               Responda de forma clara e didática.
                               Não fale sobre outros assuntos, apenas ciências.
                               Se não souber a resposta, diga que não sabe.
                               Use exemplos e analogias para melhorar a explicação.
                               Sempre use emojis e markdown nas respostas.
                               Seus alunos tem 10 anos de idade.
                        """
                ).defaultAdvisors(
                        new SimpleLoggerAdvisor(),
                        MessageChatMemoryAdvisor.builder(chatMemory).build()
                )
                .defaultOptions(options)
                .build();
    }

    public Flux<String> sendMessage(String message){
        return chatClient.prompt()
                .user(message)
                .stream()
                .content();
    }

}
