package fiap.com.br.chatprof.views;

import com.vaadin.flow.component.Unit;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.messages.MessageInput;
import com.vaadin.flow.component.messages.MessageList;
import com.vaadin.flow.component.messages.MessageListItem;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import fiap.com.br.chatprof.service.ChatService;

import java.time.Instant;
import java.util.Arrays;

@Route
public class HomeView extends VerticalLayout {
    private final ChatService chatService;
    private MessageList list = new MessageList();

    public HomeView(ChatService chatService) {

        add(new H1("Chat de Ciêncas"));

        MessageInput input = new MessageInput();
        input.addSubmitListener(submitEvent -> {
            String messageText = submitEvent.getValue();
            addMessage(messageText, "Você");

            var reponseMessage = new MessageListItem("", Instant.now(), "Professor");
            list.addItem(reponseMessage);
            chatService.sendMessage(messageText).subscribe(partialResponse -> {
                getUI().ifPresent(ui -> ui.access(() -> {
                    reponseMessage.appendText(partialResponse);
                }));
            });


        });
        input.setWidthFull();

        list.setHeightFull();
        list.setWidthFull();
        list.setMarkdown(true);
        setHeightFull();

        add(list);
        add(input);
        this.chatService = chatService;
    }

    private void addMessage(String messageText, String userName) {
        var message = new MessageListItem(messageText, Instant.now(), userName);
        message.setUserColorIndex(1);
        list.addItem(message);
    }
}
