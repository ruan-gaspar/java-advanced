import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ApiService } from '../service/api.service';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  private apiService = inject(ApiService);
  private authService = inject(AuthService);
  private router = inject(Router);


 loginForm = new FormGroup({
    username: new FormControl(''),
    password: new FormControl('')
  })

  onSubmit() {
    this.apiService.login(
      this.loginForm.getRawValue().username,
      this.loginForm.getRawValue().password).subscribe({
        next: (response) => {
          this.authService.login(response.token);
          this.router.navigate(['/home']);
        },
        error: (error) => console.error('Login failed:', error)
      })

  }
}
