package fiap.com.br.ecommerce.validation;

import fiap.com.br.ecommerce.dto.UserRequest;
import fiap.com.br.ecommerce.entity.Role;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class UserRoleValidator implements ConstraintValidator<UserRoleValidation, UserRequest> {
    @Override
    public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {
        if(userRequest.role() == Role.CLIENT){
            if(userRequest.cpf() == null || userRequest.cpf().isBlank()){
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate("CPF é obrigatório para clientes")
                        .addPropertyNode("cpf")
                        .addConstraintViolation();

                return false;
            }
        }

        if(userRequest.role() == Role.SUPPLIER){
            if(userRequest.cnpj() == null || userRequest.cnpj().isBlank()){
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate("CNPJ é obrigatório para fornecedores")
                        .addPropertyNode("cnpj")
                        .addConstraintViolation();

                return false;
            }
        }

        return true;
    }
}
