package fiap.com.br.ecommerce.dto;

import fiap.com.br.ecommerce.entity.User;

import java.time.LocalDate;

public record UserResponse(
        Long id,
        String name,
        String email,
        LocalDate birthDate,
        Integer rating
) {
    public static UserResponse fromEntity(User u) {
        return new UserResponse(
                u.getId(),
                u.getName(),
                u.getEmail(),
                u.getBirthDate(),
                u.getRating()
        );
    }
}
