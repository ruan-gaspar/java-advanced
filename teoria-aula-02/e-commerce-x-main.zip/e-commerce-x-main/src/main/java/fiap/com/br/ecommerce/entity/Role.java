package fiap.com.br.ecommerce.entity;

public enum Role {
    ADMIN,
    CLIENT,
    SUPPLIER
}
