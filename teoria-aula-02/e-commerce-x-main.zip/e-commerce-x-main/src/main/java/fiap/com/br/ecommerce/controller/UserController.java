package fiap.com.br.ecommerce.controller;

import fiap.com.br.ecommerce.dto.UserRequest;
import fiap.com.br.ecommerce.dto.UserResponse;
import fiap.com.br.ecommerce.entity.User;
import fiap.com.br.ecommerce.repository.UserRepository;
import fiap.com.br.ecommerce.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public User addUser(@RequestBody @Valid UserRequest userRequest){
        return userService.addUser(userRequest.toEntity());
    }

    @GetMapping
    public List<UserResponse> findAll(){
        return userService.findAll().stream()
                .map(UserResponse::fromEntity) //method reference
                .toList();
    }
}
