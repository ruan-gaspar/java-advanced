INSERT INTO movie VALUES (
  1,
  'Titanic',
  'Todos morrem no final',
    9.5,
  'https://media.themoviedb.org/t/p/w440_and_h660_face/As0zX43h3w6kD2NS4uVHu9HKdEh.jpg'
 );