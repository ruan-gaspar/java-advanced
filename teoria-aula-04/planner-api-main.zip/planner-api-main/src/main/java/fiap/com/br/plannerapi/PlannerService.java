package fiap.com.br.plannerapi;


import org.springframework.stereotype.Service;

@Service
public class PlannerService {

    public PlannerResponse planActivities(WeatherResponse weatherResponse, String activity) {
        String response = switch (activity){
            case "Ver as estrelas" -> shouldGoOut(weatherResponse);
            case "Voar de balão" -> shouldFlyBalloon(weatherResponse);
            default -> "Atividade não reconhecida.";
        };
        return new PlannerResponse(response);
    }

    private String shouldGoOut(WeatherResponse weatherResponse) {
        if (weatherResponse.currentWeather().isDay() == 1) {
            return "Não é recomendado sair para ver as estrelas, está de dia.";
        }
        if (weatherResponse.currentWeather().weathercode() > 2) {
            return "Não é recomendado sair para ver as estrelas, está nublado.";
        }
        return "O céu está limpo nesta noite, é um bom momento para ver as estrelas!";

    }

    private String shouldFlyBalloon(WeatherResponse weatherResponse) {
        if (weatherResponse.currentWeather().windspeed() > 20) {
            return "Não é recomendado viajar de balão, o vento está muito forte.";
        }
        if (weatherResponse.currentWeather().weathercode() > 4) {
            return "Não é recomendado viajar de balão, está muito nublado.";
        }

        return "As condições estão favoráveis para viajar de balão!";

    }

}