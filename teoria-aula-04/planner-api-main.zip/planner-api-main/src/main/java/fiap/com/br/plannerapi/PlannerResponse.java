package fiap.com.br.plannerapi;

public record PlannerResponse(String response) {
}
