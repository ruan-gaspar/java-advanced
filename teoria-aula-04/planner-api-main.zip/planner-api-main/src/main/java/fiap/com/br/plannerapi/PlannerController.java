package fiap.com.br.plannerapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/planner")
public class PlannerController {

    private final PlannerService plannerService;
    private WeatherService weatherService;

    public PlannerController(WeatherService weatherService, PlannerService plannerService) {
        this.weatherService = weatherService;
        this.plannerService = plannerService;
    }

    @GetMapping
    public PlannerResponse getPanner(@RequestParam String activity){
        return plannerService.planActivities(weatherService.getWeather(), activity);
    }

}
