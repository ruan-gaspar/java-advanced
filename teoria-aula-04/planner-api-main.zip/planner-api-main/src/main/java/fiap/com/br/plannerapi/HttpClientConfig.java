package fiap.com.br.plannerapi;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.service.registry.ImportHttpServices;

@Configuration
@ImportHttpServices(WeatherService.class)
public class HttpClientConfig {
}
