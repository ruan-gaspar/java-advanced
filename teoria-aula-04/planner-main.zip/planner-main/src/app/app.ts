import { Component, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Card } from './card/card';
import { ApiService } from './service/api.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Card],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  apiService = inject(ApiService);
  protected readonly title = signal('planner');
  apiResponse = signal<string>('');

  handleCardClick(activity: string){
    this.apiService.getPlanner(activity).subscribe({

      next: r => this.apiResponse.set(JSON.stringify(r)),
      error: error => this.apiResponse.set("Erro ao busca atividade." + error.message)
    })
  }
}
